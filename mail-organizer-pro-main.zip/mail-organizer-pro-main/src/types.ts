
export interface EmailGroups {
  personal: Record<string, string[]>;
  corporate: Record<string, string[]>;
  educational: Record<string, string[]>;
  others: Record<string, string[]>;
}
